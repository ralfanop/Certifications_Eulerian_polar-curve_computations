"""Recheck saved decimal cells from exact binary endpoints, without Arb evaluations."""
import hashlib,json
from pathlib import Path
from flint import fmpz

root=Path(__file__).resolve().parent
c=json.loads((root/'CERTIFICATE.json').read_text())
for value in c['values']:
    for name,digest in value['files'].items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
    name=value['unit']; d=value['certified_decimal_places']; scale=fmpz(10)**d
    bounds=json.loads((root/(name+'_exact_binary_endpoints.json')).read_text())
    a={k:(fmpz(int(v['numerator'],16)),fmpz(int(v['denominator'],16))) for k,v in bounds.items() if k!='base'}
    for kind in ['truncated','rounded']:
        text=(root/(name+'_1000001_decimals_'+kind+'.txt')).read_text().strip()
        whole,decimal=text.split('.')
        assert len(decimal)==d
        k=fmpz(whole+decimal)
        for num,den in a.values():
            if kind=='truncated': assert k*den<num*scale<(k+1)*den
            else: assert (2*k-1)*den<2*num*scale<(2*k+1)*den
    assert value['operating_bits']==3600000 and value['relative_accuracy_bits']>=3400000
    print('success:',name,d,'decimal places; exact endpoint cell checks and all hashes')
