"""Private reproducible certificate for Manuscript 15, Theorem 7.3.

Two independent exact constructions of Eulerian coefficients are compared.
The numerical certificate uses Arb balls and then exact rational endpoint
comparisons to certify truncation AND rounding to 1,000,001 decimal places.
No publication, network access, or external repository writes occur here.
"""
import argparse
import hashlib
import json
import platform
import sys
import time
from fractions import Fraction
from math import comb, factorial
from pathlib import Path

import flint
from flint import arb, ctx, fmpz

ROOT = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def exact_checks():
    row = [1]
    results = []
    for n in range(2, 72):
        old = [0] + row + [0]
        row = [(k+1)*old[k+1] + (n-k)*old[k] for k in range(n)]
        assert sum(row) == factorial(n) and row == row[::-1]
        if n < 3:
            continue
        k = (n-1)//2
        def explicit(j):
            return sum((-1)**i * comb(n+1,i) * (j+1-i)**n for i in range(j+2))
        a, b = explicit(k), explicit(k-1)
        assert (a,b) == (row[k],row[k-1])
        slope = Fraction((n+1)*(a-b),factorial(n))
        peak = Fraction(9473633,3628800)
        assert slope > 0
        assert (slope == peak) == (n == 12)
        assert slope <= peak
        if n % 2:
            assert (slope == 2) == (n in [3,5])
            assert slope <= 2
        else:
            assert (slope > 2) == (n <= 48)
            assert slope != 2
        results.append(dict(n=n, central=str(a), previous=str(b),
                            numerator=str(slope.numerator),denominator=str(slope.denominator)))
    assert len([x for x in results if x['n'] % 2 == 0]) == 34
    assert Fraction(288,73) < Fraction(199,100)**2
    assert Fraction(584,72*3**73) < Fraction(1,100)
    (ROOT/'exact_comparisons.json').write_text(json.dumps(results,indent=2)+'\n')
    print('success: independent explicit formula versus recurrence; 34 even orders and 35 odd orders',flush=True)

def decimal_text(integer, digits):
    s = str(integer).rjust(digits+1,'0')
    return s[:-digits]+'.'+s[-digits:]+'\n'

def certify(name,value,bits,digits):
    accuracy = int(value.rel_accuracy_bits())
    assert accuracy >= 3_400_000, (name,accuracy)
    lo,hi = value.lower().fmpq(),value.upper().fmpq()
    assert 0 < lo < hi
    scale = fmpz(10)**digits
    low_floor = (lo.numerator*scale)//lo.denominator
    high_floor = (hi.numerator*scale)//hi.denominator
    assert low_floor == high_floor, name+' truncation cell not unique'
    low_round = (2*lo.numerator*scale+lo.denominator)//(2*lo.denominator)
    high_round = (2*hi.numerator*scale+hi.denominator)//(2*hi.denominator)
    assert low_round == high_round, name+' rounding cell not unique'
    assert lo.numerator*scale > low_floor*lo.denominator
    assert hi.numerator*scale < (low_floor+1)*hi.denominator
    assert 2*lo.numerator*scale > (2*low_round-1)*lo.denominator
    assert 2*hi.numerator*scale < (2*low_round+1)*hi.denominator
    trunc=ROOT/(name+'_1000001_decimals_truncated.txt')
    rounded=ROOT/(name+'_1000001_decimals_rounded.txt')
    trunc.write_text(decimal_text(low_floor,digits))
    rounded.write_text(decimal_text(low_round,digits))
    endpoints=ROOT/(name+'_exact_binary_endpoints.json')
    endpoints.write_text(json.dumps({
        'base':16,
        'lower':{'numerator':lo.numerator.str(16),'denominator':lo.denominator.str(16)},
        'upper':{'numerator':hi.numerator.str(16),'denominator':hi.denominator.str(16)}
    })+'\n')
    result={'unit':name,'operating_bits':bits,'relative_accuracy_bits':accuracy,
            'certified_decimal_places':digits,'preview':value.str(60),
            'truncation_cell_verified_by_exact_rationals':True,
            'rounding_cell_verified_by_exact_rationals':True,
            'files':{p.name:sha(p) for p in [trunc,rounded,endpoints]}}
    print(json.dumps({k:v for k,v in result.items() if k!='files'}),flush=True)
    return result

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--bits',type=int,default=3_600_000)
    parser.add_argument('--digits',type=int,default=1_000_001)
    args=parser.parse_args()
    started=time.monotonic()
    exact_checks()
    ctx.prec=args.bits
    print('Computing rigorous Arb angle at',ctx.prec,'bits',flush=True)
    q=arb(3628800)/arb(9473633)
    radians=2*q.atan()
    degrees=180*radians/arb.pi()
    assert radians > 0 and radians < 2*(arb(1)/2).atan()
    # Independent trigonometric representation on the certified principal branch.
    cos_angle=arb(9473633**2-3628800**2)/arb(9473633**2+3628800**2)
    alt=cos_angle.acos()
    assert radians.overlaps(alt)
    cert={'private':True,'theorem':'Manuscript 15, Theorem 7.3',
          'exact_radians':'2*atan(3628800/9473633)',
          'exact_degrees':'360*atan(3628800/9473633)/pi',
          'python_flint_version':flint.__version__,
          'flint_version':flint.__FLINT_VERSION__,
          'python':sys.version,'platform':platform.platform(),
          'alternative_acos_relative_accuracy_bits':int(alt.rel_accuracy_bits()),
          'alternative_acos_overlap_verified':True,
          'values':[certify('radians',radians,args.bits,args.digits),
                    certify('degrees',degrees,args.bits,args.digits)]}
    cert['elapsed_seconds']=time.monotonic()-started
    cert['source_sha256']=sha(Path(__file__))
    (ROOT/'CERTIFICATE.json').write_text(json.dumps(cert,indent=2)+'\n')
    print('success:',round(cert['elapsed_seconds'],2),'seconds',flush=True)

if __name__=='__main__':
    main()
